# Zoomsl v3.0 And FlexSlider
ตัวอย่างการใช้งาน plugin [ImageZoom](http://zoomsl.sergeland.ru/) กับ [Flexslider](http://flexslider.woothemes.com/) 
<p align="center"><img src="/images/zoomsl.png" /></p>
